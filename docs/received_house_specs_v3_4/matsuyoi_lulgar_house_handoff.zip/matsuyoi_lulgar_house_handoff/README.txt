『待宵物語』ルルガー家 外観・内観 最小仕様 引き渡しパッケージ

内容:
- matsuyoi_lulgar_house_minimum_spec.md
  実装仕様書
- matsuyoi_lulgar_house_minimum_manifest.csv
  semantic name / priority / collision 付き manifest

用途:
第一章前半の中心舞台であるルルガー家を、
実装部門がそのままプロトタイプへ組み込めるようにした引き渡し用資料。

優先:
まずは「村長宅である」「家庭の場である」「郵便や来客に対応できる」
の3点を成立させること。
