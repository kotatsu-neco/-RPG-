『待宵物語』コルパン家 最小内観セット 引き渡しパッケージ

内容:
- matsuyoi_colpan_house_minimum_interior_spec.md
  実装仕様書
- matsuyoi_colpan_house_minimum_interior_manifest.csv
  semantic name / priority / collision 付き manifest

用途:
第一章冒頭で使用するコルパン家の最小内観セットを、
実装部門がそのままプロトタイプへ組み込めるようにした引き渡し用資料。

優先:
まずは「帰る家である」「母のメモが自然に置かれている」「生活感がある」
の3点を成立させること。
